# 🤖 Auto Robô v2.0 - Automação Corporativa Modular

> Projeto desenvolvido por **Tiago Cesar Soares dos Santos (xAgron)** como parte dos estudos em Análise e Desenvolvimento de Sistemas.

## 📋 Sobre o Projeto
Sistema de automação web desenvolvido em **Node.js** com **Puppeteer**, projetado para interagir com sistemas corporativos internos (GOI, WFM, GPS). O projeto foca em **modularidade**, **tratamento robusto de erros** e **flexibilidade de configuração**, permitindo execução tanto em ambiente corporativo (VPN) quanto em desenvolvimento local (Mock Server).

## 🚀 Tecnologias Utilizadas
- **Node.js** (ES Modules)
- **Puppeteer** (Automação Headless Chrome)
- **Express** (Servidor Mock para testes locais)
- **Dotenv** (Gerenciamento de variáveis de ambiente)
- **Arquitetura Modular** (Separação de Config, Browser, Services e Utils)

## 🏗️ Arquitetura
O projeto segue o padrão de separação de responsabilidades:
- `src/config/`: Centralização de URLs, credenciais e timeouts.
- `src/browser/`: Gerenciamento do ciclo de vida do navegador (Launch/Connect).
- `src/services/`: Lógica de negócio (Login, Injeção, Navegação).
- `src/utils/`: Ferramentas reutilizáveis (Logger, Wait, Screenshots).

## 🛠️ Instalação e Configuração

### Pré-requisitos
- Node.js v18+
- Google Chrome instalado

### Passos
1. Clone o repositório:
   ```bash
   git clone <seu-repo>
   cd auto-robo-main
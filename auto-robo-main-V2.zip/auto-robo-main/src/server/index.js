// src/server/index.js
import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import fs from 'fs';
import { lookup } from 'dns';
import { request } from 'http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: "*" }
});

const PORT = process.env.WEB_PORT || 3000;

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, '../../public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/index.html'));
});

// === ENDPOINT DE DIAGNÓSTICO ===
app.get('/api/diagnose', async (req, res) => {
  const diagnostics = {
    mock: false,
    vpn: false,
    error: null
  };

  // Testa Mock Server (localhost:3456)
  try {
    const mockReq = new Promise((resolve) => {
      const req = request({
        hostname: 'localhost',
        port: 3456,
        path: '/login',
        method: 'HEAD',
        timeout: 3000
      }, (response) => {
        resolve(response.statusCode === 200);
      });
      req.on('error', () => resolve(false));
      req.on('timeout', () => {
        req.destroy();
        resolve(false);
      });
    });
    diagnostics.mock = await mockReq;
  } catch {
    diagnostics.mock = false;
  }

  // Testa Rede Corporativa (DNS + HTTP)
  try {
    // DNS Lookup
    await new Promise((resolve, reject) => {
      lookup('goi.vivo.com.br', (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
    // HTTP Request básico
    const httpReq = new Promise((resolve) => {
      const req = request({
        hostname: 'goi.vivo.com.br',
        port: 443,
        path: '/login',
        method: 'HEAD',
        timeout: 5000
      }, (resHttp) => {
        resolve(resHttp.statusCode < 500); // Aceita 2xx, 3xx, 4xx
      });
      req.on('error', () => resolve(false));
      req.on('timeout', () => {
        req.destroy();
        resolve(false);
      });
      req.end();
    });
    diagnostics.vpn = await httpReq;
  } catch {
    diagnostics.vpn = false;
  }

  res.json(diagnostics);
});

let robotProcess = null;

io.on('connection', (socket) => {
  console.log('🔌 Cliente conectado ao Dashboard');

  socket.on('start-robot', async (data) => {
    if (robotProcess) {
      socket.emit('log', { level: 'warn', msg: '⚠️ Robô já está em execução. Aguarde finalizar.' });
      return;
    }

    const mode = data.mode; // 'DEV' ou 'PROD'
    socket.emit('log', { level: 'info', msg: `🚀 Iniciando Robô no modo: ${mode}` });

    // === Diagnóstico Pré-Execução ===
    let canProceed = true;
    if (mode === 'DEV') {
      // Verifica Mock Server
      try {
        const mockRes = await fetch('http://localhost:3456/login', { method: 'HEAD', signal: AbortSignal.timeout(3000) });
        if (!mockRes.ok) throw new Error();
        socket.emit('log', { level: 'success', msg: '✅ Mock Server está ONLINE' });
      } catch {
        socket.emit('log', { level: 'error', msg: '❌ Mock Server NÃO está rodando!' });
        socket.emit('log', { level: 'info', msg: '💡 Execute em outro terminal: npm run mock' });
        canProceed = false;
      }
    } else if (mode === 'PROD') {
      // Verifica acesso corporativo
      try {
        await new Promise((resolve, reject) => {
          lookup('goi.vivo.com.br', (err) => err ? reject(err) : resolve());
        });
        socket.emit('log', { level: 'success', msg: '✅ Rede corporativa acessível (DNS OK)' });
      } catch {
        socket.emit('log', { level: 'error', msg: '❌ Sem acesso à rede corporativa (VPN/cabo)' });
        socket.emit('log', { level: 'warn', msg: '⚠️ O modo PROD só funciona no escritório ou com VPN ativa.' });
        canProceed = false;
      }
    }

    if (!canProceed) {
      socket.emit('status', { running: false });
      return;
    }

    // === Configuração do Ambiente ===
    const env = { ...process.env };
    if (mode === 'DEV') {
      env.MODO_TESTE = 'true';
      env.LOGIN_URL = 'http://localhost:3456/login';
      env.AGENDAMENTO_URL = 'http://localhost:3456/agendamento/atendimento.php';
      env.WFM_LOGIN_URL = 'http://localhost:3456/login';
      env.WFM_URL = 'http://localhost:3456/agendamento/atendimento.php';
      env.GPS_URL = 'http://localhost:3456/login';
      env.HEADLESS = 'false';
      socket.emit('log', { level: 'info', msg: '🔧 Configurado para Mock Local (Porta 3456)' });
    } else {
      env.MODO_TESTE = 'false';
      socket.emit('log', { level: 'info', msg: '🔧 Configurado para Produção (URLs do .env)' });
    }

    // === Validação do Arquivo Principal ===
    const projectRoot = path.join(__dirname, '../..');
    const indexPath = path.join(projectRoot, 'index.js');
    if (!fs.existsSync(indexPath)) {
      socket.emit('log', { level: 'error', msg: `❌ Arquivo principal não encontrado: index.js` });
      socket.emit('status', { running: false });
      return;
    }

    console.log(`[SERVER] Iniciando processo filho: node index.js em ${projectRoot}`);
    robotProcess = spawn('node', ['index.js'], {
      cwd: projectRoot,
      env: env,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    socket.emit('status', { running: true });

    // === Captura de Logs ===
    let stdoutBuffer = '';
    let stderrBuffer = '';

    const emitLogLine = (line, defaultLevel = 'info') => {
      if (!line.trim()) return;
      let level = defaultLevel;
      if (line.includes('❌') || line.includes('ERROR')) level = 'error';
      else if (line.includes('⚠️') || line.includes('WARN')) level = 'warn';
      else if (line.includes('✅') || line.includes('SUCCESS')) level = 'success';
      socket.emit('log', { level, msg: line.trim() });
    };

    robotProcess.stdout.on('data', (data) => {
      stdoutBuffer += data.toString();
      const lines = stdoutBuffer.split('\n');
      stdoutBuffer = lines.pop() || '';
      lines.forEach(line => emitLogLine(line));
    });

    robotProcess.stderr.on('data', (data) => {
      stderrBuffer += data.toString();
      const lines = stderrBuffer.split('\n');
      stderrBuffer = lines.pop() || '';
      lines.forEach(line => emitLogLine(line, 'error'));
    });

    robotProcess.on('close', (code) => {
      console.log(`[SERVER] Processo filho encerrou com código ${code}`);
      const msg = code === 0 
        ? '🏁 Automação concluída com sucesso!' 
        : `💥 Automação falhou (Código: ${code})`;
      socket.emit('log', { level: code === 0 ? 'success' : 'error', msg });
      socket.emit('status', { running: false });
      robotProcess = null;
    });

    robotProcess.on('error', (err) => {
      console.error('[SERVER] Erro ao spawnar processo:', err);
      socket.emit('log', { level: 'error', msg: `❌ Falha crítica: ${err.message}` });
      socket.emit('status', { running: false });
      robotProcess = null;
    });
  });

  socket.on('disconnect', () => {
    console.log('🔌 Cliente desconectado');
  });
});

httpServer.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════╗
║  🌐 Dashboard do Auto Robô v2.0                        ║
║  Acesse: http://localhost:${PORT}                       ║
╚════════════════════════════════════════════════════════╝
  `);
});
// src/config/systems.js
import dotenv from 'dotenv';
dotenv.config();

export default {
  goi: {
    loginUrl: process.env.LOGIN_URL,
    email: process.env.LOGIN_EMAIL,
    password: process.env.LOGIN_PASSWORD,
    agendamentoUrl: process.env.AGENDAMENTO_URL,
    homeUrl: 'https://goi.vivo.com.br/home/index.php'
  },
  
  wfm: {
    loginUrl: process.env.WFM_LOGIN_URL,
    detailsUrl: process.env.WFM_URL,
    username: process.env.WFM_USERNAME,
    password: process.env.WFM_PASSWORD,
    autoLogin: process.env.WFM_AUTO_LOGIN === 'true'
  },
  
  gps: {
    url: process.env.GPS_URL
  },
  
  // Flags de controle
  abrirWFM: process.env.ABRIR_WFM === 'true',
  abrirGPS: process.env.ABRIR_GPS === 'true'
};
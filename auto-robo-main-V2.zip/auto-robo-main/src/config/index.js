// src/config/index.js
export { default as puppeteerConfig } from './puppeteer.js';
export { default as systemsConfig } from './systems.js';
export { default as automationConfig } from './automation.js';

// Exporta tudo em um objeto único para conveniência
import puppeteerConfig from './puppeteer.js';
import systemsConfig from './systems.js';
import automationConfig from './automation.js';

export default {
  puppeteer: puppeteerConfig,
  systems: systemsConfig,
  automation: automationConfig
};
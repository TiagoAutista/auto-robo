// src/config/puppeteer.js
import dotenv from 'dotenv';
dotenv.config();

const parseArgs = (argsStr) => {
  if (!argsStr) return [];
  return argsStr.split(',').map(arg => arg.trim()).filter(Boolean);
};

export default {
  // Modo de conexão
  usarChromeExistente: process.env.USAR_CHROME_EXISTENTE === 'true',
  
  // Conexão CDP (Chrome existente)
  debugPort: process.env.CHROME_DEBUG_PORT || '9222',
  debugUrl: process.env.CHROME_DEBUG_URL || 'http://localhost:9222',
  
  // Chrome instalado (fallback)
  chromePath: process.env.CHROME_PATH,
  
  // Comportamento
  headless: process.env.HEADLESS === 'true' ? 'new' : false,
  slowMo: parseInt(process.env.SLOW_MO) || 0,
  userDataDir: process.env.CHROME_USER_DATA_DIR,
  
  // Args do Chromium
  args: parseArgs(process.env.PUPPETEER_ARGS),
  
  // Segurança e rede
  ignoreHTTPSErrors: process.env.IGNORE_HTTPS_ERRORS === 'true',
  
  // Debug
  debug: process.env.PUPPETEER_DEBUG === 'true',
  
  // Viewport
  defaultViewport: null, // Usa tamanho nativo da janela
  
  // Helpers
  getLaunchOptions() {
    return {
      headless: this.headless,
      args: this.args,
      defaultViewport: this.defaultViewport,
      slowMo: this.slowMo,
      ignoreHTTPSErrors: this.ignoreHTTPSErrors,
      ...(this.chromePath && { executablePath: this.chromePath }),
      ...(this.userDataDir && { userDataDir: this.userDataDir })
    };
  },
  
  getConnectOptions() {
    return {
      browserURL: this.debugUrl,
      defaultViewport: this.defaultViewport,
      slowMo: this.slowMo
    };
  }
};
// src/config/automation.js
import dotenv from 'dotenv';
dotenv.config();

export default {
  // Timeouts (ms)
  defaultTimeout: parseInt(process.env.DEFAULT_TIMEOUT) || 60000,
  elementWaitTimeout: parseInt(process.env.ELEMENT_WAIT_TIMEOUT) || 30000,
  
  // Retry
  maxRetries: parseInt(process.env.MAX_RETRIES) || 3,
  retryDelay: parseInt(process.env.RETRY_DELAY) || 2000,
  
  // Debug e output
  debugScreenshots: process.env.DEBUG_SCREENSHOTS === 'true',
  outputDir: process.env.OUTPUT_DIR || './output',
  
  // Logs
  logLevel: process.env.LOG_LEVEL || 'info', // debug, info, warn, error
  
  // Dados de teste
  atividadeTeste: process.env.ATIVIDADE_TESTE,
  
  // Helpers
  shouldLog(level) {
    const levels = { debug: 0, info: 1, warn: 2, error: 3 };
    return levels[level] >= levels[this.logLevel];
  }
};
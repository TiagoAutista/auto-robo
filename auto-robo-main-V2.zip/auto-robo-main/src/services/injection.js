// src/services/injection.js
import { systemsConfig, automationConfig } from '../config/index.js';
import logger from '../utils/logger.js';
import { waitForSelectorWithRetry, sleep } from '../utils/wait.js';
import { safeClick } from '../browser/utils.js';
import selectors from '../utils/selectors.js';
import { captureError } from '../utils/screenshots.js';

/**
 * Navega para aba "Injeção D0" e executa a função analítica
 */
export const executarInjecaoD0 = async (page, filters = {}) => {
  const module = 'injection';
  logger.info(module, 'Executando rotina de Injeção D0...');
  
  try {
    // Navega para página de agendamento
    logger.info(module, `🌐 Acessando: ${systemsConfig.goi.agendamentoUrl}`);
    await page.goto(systemsConfig.goi.agendamentoUrl, {
      waitUntil: 'networkidle2',
      timeout: automationConfig.defaultTimeout
    });
    
    // Aguarda e clica na aba Injeção
    logger.debug(module, 'Selecionando aba "Injeção D0"...');
    await waitForSelectorWithRetry(page, selectors.goi.agendamento.tabs.injecao, { module });
    await safeClick(page, selectors.goi.agendamento.tabs.injecao);
    
    // Aguarda aba ficar ativa
    await waitForSelectorWithRetry(page, selectors.goi.agendamento.tabs.injecaoActive, { 
      timeout: 10000, module 
    });
    logger.debug(module, '✅ Aba "Injeção D0" ativa');
    
    // Executa função JavaScript da página (injecaoAnalitico)
    logger.info(module, '⚙️  Executando injecaoAnalitico()...');
    const { status = 'pendente', tipo = 'TODOS', origem = 'atendimento' } = filters;
    
    await page.evaluate((s, t, o) => {
      if (typeof injecaoAnalitico === 'function') {
        injecaoAnalitico(s, t, o);
      }
    }, status, tipo, origem);
    
    // Aguarda tabela carregar
    await waitForSelectorWithRetry(page, selectors.goi.agendamento.table.row, { module });
    logger.success(module, '✅ injecaoAnalitico executado com sucesso');
    
    return true;
    
  } catch (error) {
    logger.error(module, `Falha na Injeção D0: ${error.message}`, error);
    await captureError(page, 'injecao_d0', error);
    throw error;
  }
};

/**
 * Busca e atribui uma atividade específica
 */
export const buscarEAtribuirAtividade = async (page, atividadeId) => {
  const module = 'injection:assign';
  logger.info(module, `🎯 Buscando atividade: ${atividadeId}`);
  
  try {
    // Aguarda tabela estar visível
    await waitForSelectorWithRetry(page, selectors.goi.agendamento.table.container, { module });
    
    // Busca linha que contém o ID da atividade
    const rowHandle = await page.evaluateHandle((id) => {
      const rows = document.querySelectorAll('table tbody tr');
      for (const row of rows) {
        if (row.textContent.includes(id)) {
          return row;
        }
      }
      return null;
    }, atividadeId);
    
    const rowExists = await rowHandle.jsonValue();
    if (!rowExists) {
      logger.warn(module, `⚠️  Atividade ${atividadeId} não encontrada na tabela`);
      return false;
    }
    
    logger.debug(module, '✅ Linha da atividade localizada');
    
    // Tenta clicar no botão de atribuir dentro da linha
    try {
      await page.evaluate((row) => {
        // Tenta múltiplos seletores possíveis para o botão
        const btn = row.querySelector('button[onclick*="atribuir"], .btn-atribuir, [data-action="atribuir"]');
        if (btn) btn.click();
      }, rowHandle);
      
      await sleep(1000); // Aguarda ação ser processada
      logger.success(module, '✅ Botão de atribuição clicado');
      return true;
      
    } catch (clickError) {
      logger.warn(module, `⚠️  Não foi possível clicar: ${clickError.message}`);
      await captureError(page, 'atribuicao_clique', clickError);
      return false;
    }
    
  } catch (error) {
    logger.error(module, `Falha na busca/atribuição: ${error.message}`, error);
    await captureError(page, 'busca_atividade', error);
    throw error;
  }
};

export default {
  executarInjecaoD0,
  buscarEAtribuirAtividade
};
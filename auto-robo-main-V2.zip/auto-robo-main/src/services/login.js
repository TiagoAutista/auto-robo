// src/services/login.js
import { systemsConfig, automationConfig } from '../config/index.js';
import logger from '../utils/logger.js';
import { waitForSelectorWithRetry, sleep } from '../utils/wait.js';
import { humanType, safeClick } from '../browser/utils.js';
import selectors from '../utils/selectors.js';

/**
 * Realiza login no sistema GOI
 */
export const loginGOI = async (page) => {
  const module = 'login:goi';
  logger.info(module, 'Iniciando login no GOI...');
  
  try {
    // Navega para página de login
    logger.info(module, `🌐 Acessando: ${systemsConfig.goi.loginUrl}`);
    await page.goto(systemsConfig.goi.loginUrl, { 
      waitUntil: 'networkidle2', 
      timeout: automationConfig.defaultTimeout 
    });
    
    // Aguarda campos de login
    logger.debug(module, 'Aguardando campos de login...');
    await waitForSelectorWithRetry(page, selectors.goi.login.email, { module });
    await waitForSelectorWithRetry(page, selectors.goi.login.password, { module });
    
    // Preenche credenciais
    logger.debug(module, 'Preenchendo credenciais...');
    await humanType(page, selectors.goi.login.email, systemsConfig.goi.email, { delay: 50 });
    await humanType(page, selectors.goi.login.password, systemsConfig.goi.password, { delay: 50 });
    
    // Aguarda usuário resolver CAPTCHA manualmente (se existir)
    const captchaExists = await page.$(selectors.goi.login.captchaContainer);
    if (captchaExists) {
      logger.warn(module, '🔐 CAPTCHA detectado! Aguardando resolução manual...');
      console.log('\n👉 Resolva o CAPTCHA e pressione ENTER para continuar...');
      await new Promise(resolve => {
        process.stdin.resume();
        process.stdin.once('data', () => {
          process.stdin.pause();
          resolve();
        });
      });
      logger.info(module, '✅ CAPTCHA resolvido');
    }
    
    // Clica no botão de login
    logger.info(module, '🔑 Realizando login...');
    await Promise.all([
      safeClick(page, selectors.goi.login.submit),
      page.waitForNavigation({ 
        waitUntil: 'networkidle2', 
        timeout: automationConfig.defaultTimeout 
      })
    ]);
    
    // Verifica se está na página inicial
    const currentUrl = page.url();
    if (!systemsConfig.goi.homeUrl.includes(currentUrl) && !currentUrl.includes('home')) {
      throw new Error(`Redirecionamento falhou. URL atual: ${currentUrl}`);
    }
    
    logger.success(module, 'Login no GOI realizado com sucesso!');
    return true;
    
  } catch (error) {
    logger.error(module, `Falha no login GOI: ${error.message}`, error);
    throw error;
  }
};

/**
 * Realiza login no WFM (se habilitado)
 */
export const loginWFM = async (page) => {
  if (!systemsConfig.abrirWFM) {
    logger.info('login:wfm', 'WFM desabilitado por configuração');
    return false;
  }
  
  const module = 'login:wfm';
  logger.info(module, 'Iniciando login no WFM...');
  
  try {
    await page.goto(systemsConfig.wfm.loginUrl, {
      waitUntil: 'networkidle2',
      timeout: automationConfig.defaultTimeout
    });
    
    // Se auto-login estiver habilitado e já estiver logado, pula
    if (systemsConfig.wfm.autoLogin) {
      const alreadyLogged = await page.$(selectors.wfm.workOrder.container);
      if (alreadyLogged) {
        logger.info(module, '✅ Já autenticado no WFM (sessão ativa)');
        return true;
      }
    }
    
    // Preenche credenciais WFM
    await waitForSelectorWithRetry(page, selectors.wfm.login.username, { module });
    await humanType(page, selectors.wfm.login.username, systemsConfig.wfm.username, { delay: 50 });
    await humanType(page, selectors.wfm.login.password, systemsConfig.wfm.password, { delay: 50 });
    
    await safeClick(page, selectors.wfm.login.submit);
    await sleep(2000); // Aguarda redirecionamento
    
    logger.success(module, 'Login no WFM realizado!');
    return true;
    
  } catch (error) {
    logger.warn(module, `Falha no login WFM (pode ser opcional): ${error.message}`);
    return false;
  }
};

export default {
  loginGOI,
  loginWFM
};
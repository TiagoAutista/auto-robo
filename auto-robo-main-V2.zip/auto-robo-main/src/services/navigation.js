// src/services/navigation.js
import { systemsConfig, automationConfig } from '../config/index.js';
import logger from '../utils/logger.js';
import { waitForSelectorWithRetry } from '../utils/wait.js';
import selectors from '../utils/selectors.js';

/**
 * Navega para uma URL e valida o carregamento
 */
export const navigateTo = async (page, url, options = {}) => {
  const { 
    waitUntil = 'networkidle2', 
    timeout = automationConfig.defaultTimeout,
    validateSelector = null,
    module = 'navigation'
  } = options;
  
  logger.debug(module, `🌐 Navegando para: ${url}`);
  
  await page.goto(url, { waitUntil, timeout });
  
  if (validateSelector) {
    await waitForSelectorWithRetry(page, validateSelector, { timeout: 10000, module });
  }
  
  logger.debug(module, `✅ Página carregada: ${page.url()}`);
  return true;
};

/**
 * Verifica se está na página correta usando URL ou selector
 */
export const validatePage = async (page, expected, options = {}) => {
  const { useUrl = true, useSelector = false, module = 'navigation' } = options;
  
  if (useUrl && typeof expected === 'string') {
    const currentUrl = page.url();
    if (currentUrl.includes(expected)) {
      logger.debug(module, `✅ URL validada: ${expected}`);
      return true;
    }
    logger.warn(module, `❌ URL não corresponde. Esperado: ${expected}, Atual: ${currentUrl}`);
    return false;
  }
  
  if (useSelector && typeof expected === 'string') {
    try {
      await page.waitForSelector(expected, { timeout: 5000 });
      logger.debug(module, `✅ Selector validado: ${expected}`);
      return true;
    } catch {
      logger.warn(module, `❌ Selector não encontrado: ${expected}`);
      return false;
    }
  }
  
  return false;
};

/**
 * Abre abas adicionais (WFM, GPS) em janelas separadas
 */
export const openSystemTabs = async (browser, page) => {
  const module = 'navigation:tabs';
  const tabs = [];
  
  if (systemsConfig.abrirWFM) {
    logger.info(module, '🔧 Abrindo WFM em nova aba...');
    const wfmPage = await browser.newPage();
    await wfmPage.goto(systemsConfig.wfm.loginUrl, { waitUntil: 'networkidle2' });
    tabs.push({ name: 'WFM', page: wfmPage });
  }
  
  if (systemsConfig.abrirGPS) {
    logger.info(module, '📍 Abrindo GPS em nova aba...');
    const gpsPage = await browser.newPage();
    await gpsPage.goto(systemsConfig.gps.url, { waitUntil: 'networkidle2' });
    tabs.push({ name: 'GPS', page: gpsPage });
  }
  
  logger.info(module, `✅ ${tabs.length} aba(s) adicional(is) aberta(s)`);
  return tabs;
};

export default {
  navigateTo,
  validatePage,
  openSystemTabs
};
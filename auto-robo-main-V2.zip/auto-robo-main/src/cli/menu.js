// src/cli/menu.js
import readline from 'readline';
import { execSync } from 'child_process';
import logger from '../utils/logger.js';
import { automationConfig, systemsConfig } from '../config/index.js';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const question = (query) => new Promise((resolve) => rl.question(query, resolve));

// Cores para o menu
const COLORS = {
  reset: '\x1b[0m',
  cyan: '\x1b[36m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  bright: '\x1b[1m'
};

const showHeader = () => {
  console.clear();
  console.log(`${COLORS.cyan}
╔════════════════════════════════════════════════════════╗`);
  console.log(`${COLORS.cyan}║  🤖 AUTO ROBO v2.0 - Menu Principal              ║`);
  console.log(`${COLORS.cyan}║  Desenvolvido por: xAgron                        ║`);
  console.log(`${COLORS.cyan}╚════════════════════════════════════════════════════════╝${COLORS.reset}
`);
};

const checkMockServer = async () => {
  try {
    // Tenta fazer um fetch rápido para localhost:3456
    const response = await fetch('http://localhost:3456/login', { method: 'HEAD' });
    if (response.ok) {
      logger.success('Mock Server está ONLINE ✅');
      return true;
    }
  } catch (e) {
    logger.error('Mock Server está OFFLINE ❌');
    logger.info('Execute "npm run mock" em outro terminal.');
    return false;
  }
};

const checkVPN = async () => {
  try {
    // Tenta resolver DNS do sistema corporativo
    const dns = await import('dns').then(m => m.promises);
    await dns.lookup('goi.vivo.com.br');
    logger.success('DNS Corporativo resolvido (VPN/Cabo provável) ✅');
    return true;
  } catch (e) {
    logger.error('DNS Corporativo NÃO resolvido (Sem VPN/Cabo) ❌');
    return false;
  }
};

export const showMainMenu = async () => {
  showHeader();
  
  console.log(`${COLORS.bright}Escolha o modo de execução:${COLORS.reset}`);
  console.log(`  ${COLORS.green}[1]${COLORS.reset} Modo Desenvolvimento (Mock Local)`);
  console.log(`  ${COLORS.cyan}[2]${COLORS.reset} Modo Produção (Sistemas Reais)`);
  console.log(`  ${COLORS.yellow}[3]${COLORS.reset} Diagnóstico de Rede`);
  console.log(`  ${COLORS.red}[0]${COLORS.reset} Sair`);
  console.log('');

  const choice = await question('👉 Digite sua opção: ');

  switch (choice.trim()) {
    case '1':
      await handleDevMode();
      break;
    case '2':
      await handleProdMode();
      break;
    case '3':
      await handleDiagnostics();
      break;
    case '0':
      logger.info('Saindo...');
      rl.close();
      process.exit(0);
      break;
    default:
      logger.warn('Opção inválida. Tente novamente.');
      await new Promise(r => setTimeout(r, 1500));
      return showMainMenu(); // Recursão para mostrar o menu de novo
  }
};

const handleDevMode = async () => {
  logger.info('Configurando Modo Desenvolvimento...');
  
  // Verifica se o mock está rodando
  const isMockUp = await checkMockServer();
  
  if (!isMockUp) {
    const startMock = await question('⚠️  Mock Server não detectado. Deseja iniciar agora? (s/n): ');
    if (startMock.toLowerCase() === 's') {
      logger.info('Iniciando Mock Server em background...');
      // Nota: Em Windows, spawn detached é complexo. 
      // O ideal é pedir para o usuário abrir outro terminal.
      logger.warn('Por favor, abra OUTRO terminal e execute: npm run mock');
      await question('Pressione ENTER quando o Mock Server estiver pronto...');
    } else {
      logger.warn('Cancelando execução. Inicie o Mock Server manualmente.');
      rl.close();
      process.exit(0);
    }
  }

  // Configura variáveis para este processo
  process.env.MODO_TESTE = 'true';
  process.env.LOGIN_URL = 'http://localhost:3456/login';
  process.env.AGENDAMENTO_URL = 'http://localhost:3456/agendamento/atendimento.php';
  
  logger.success('Modo Desenvolvimento Ativado! Iniciando robô...');
  await new Promise(r => setTimeout(r, 1000));
  rl.close();
  // Retorna controle para o index.js continuar
  return 'DEV';
};

const handleProdMode = async () => {
  logger.info('Configurando Modo Produção...');
  
  // Verifica VPN
  const hasVPN = await checkVPN();
  
  if (!hasVPN) {
    const force = await question('⚠️  VPN/Rede Corporativa não detectada. Deseja continuar mesmo assim? (s/n): ');
    if (force.toLowerCase() !== 's') {
      logger.warn('Conecte-se à VPN e tente novamente.');
      rl.close();
      process.exit(0);
    }
  }

  // Configura variáveis para produção
  process.env.MODO_TESTE = 'false';
  // As URLs reais já estão no .env, então não precisamos sobrescrever,
  // a menos que queira garantir. O config/systems.js lê do .env.
  
  logger.success('Modo Produção Ativado! Iniciando robô...');
  await new Promise(r => setTimeout(r, 1000));
  rl.close();
  return 'PROD';
};

const handleDiagnostics = async () => {
  logger.info('Executando diagnóstico...');
  console.log('');
  await checkMockServer();
  await checkVPN();
  console.log('');
  await question('Pressione ENTER para voltar ao menu...');
  return showMainMenu();
};
// src/index.js
// Exporta todos os módulos para uso no entry point principal

// Configurações
export * from './config/index.js';

// Browser
export * from './browser/index.js';
export { default as browserUtils } from './browser/utils.js';

// Serviços
export { default as loginService } from './services/login.js';
export { default as injectionService } from './services/injection.js';
export { default as navigationService } from './services/navigation.js';

// Utilitários
export { default as logger } from './utils/logger.js';
export { default as selectors } from './utils/selectors.js';
export * from './utils/wait.js';
export { default as screenshotUtils } from './utils/screenshots.js';
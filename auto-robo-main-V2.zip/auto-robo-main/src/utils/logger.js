// src/utils/logger.js
import { automationConfig } from '../config/index.js';

const COLORS = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m'
};

const PREFIXES = {
  debug: { symbol: '🔍', color: COLORS.cyan },
  info: { symbol: 'ℹ️', color: COLORS.green },
  warn: { symbol: '⚠️', color: COLORS.yellow },
  error: { symbol: '❌', color: COLORS.red }
};

const formatMessage = (level, module, message) => {
  const prefix = PREFIXES[level];
  const timestamp = new Date().toISOString().slice(11, 19);
  const moduleTag = module ? `[${module}]` : '';
  
  return `${prefix.color}${prefix.symbol} [${timestamp}]${moduleTag} ${message}${COLORS.reset}`;
};

export default {
  debug(module, message) {
    if (automationConfig.shouldLog('debug')) {
      console.log(formatMessage('debug', module, message));
    }
  },
  
  info(module, message) {
    if (automationConfig.shouldLog('info')) {
      console.log(formatMessage('info', module, message));
    }
  },
  
  warn(module, message) {
    if (automationConfig.shouldLog('warn')) {
      console.warn(formatMessage('warn', module, message));
    }
  },
  
  error(module, message, error = null) {
    if (automationConfig.shouldLog('error')) {
      console.error(formatMessage('error', module, message));
      if (error) console.error(COLORS.dim, error.stack || error, COLORS.reset);
    }
  },
  
  // Shortcut para logs sem módulo
  log(message) {
    console.log(`${COLORS.bright}${message}${COLORS.reset}`);
  },
  
  success(message) {
    console.log(`${COLORS.green}✅ ${message}${COLORS.reset}`);
  },
  
  divider(char = '─', length = 60) {
    console.log(COLORS.dim + char.repeat(length) + COLORS.reset);
  }
};
// src/utils/screenshots.js
import { promises as fs } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { automationConfig } from '../config/index.js';
import logger from './logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Garante que a pasta de output exista
 */
const ensureOutputDir = async (subdir = '') => {
  const targetDir = join(automationConfig.outputDir, subdir);
  await fs.mkdir(targetDir, { recursive: true });
  return targetDir;
};

/**
 * Gera nome de arquivo com timestamp
 */
const generateFilename = (prefix, extension = 'png') => {
  const timestamp = new Date().toISOString()
    .replace(/[:.]/g, '-')
    .slice(0, -5); // Remove milissegundos e Z
  return `${prefix}_${timestamp}.${extension}`;
};

/**
 * Tira screenshot e salva em disco
 */
export const captureAndSave = async (page, prefix, options = {}) => {
  if (!automationConfig.debugScreenshots) {
    logger.debug('screenshot', 'Screenshots desabilitados por configuração');
    return null;
  }
  
  try {
    const dir = await ensureOutputDir('screenshots');
    const filename = generateFilename(prefix);
    const filepath = join(dir, filename);
    
    await page.screenshot({ 
      path: filepath, 
      fullPage: true,
      ...options 
    });
    
    logger.info('screenshot', `📸 Salvo: ${filepath}`);
    return filepath;
    
  } catch (error) {
    logger.error('screenshot', `Falha ao salvar screenshot: ${error.message}`);
    return null;
  }
};

/**
 * Screenshot de erro com contexto
 */
export const captureError = async (page, context, error) => {
  const prefix = `error_${context.replace(/\s+/g, '_').toLowerCase()}`;
  const filepath = await captureAndSave(page, prefix);
  
  // Salva também um arquivo de log do erro
  if (filepath) {
    const logPath = filepath.replace('.png', '.log');
    await fs.writeFile(logPath, `Error: ${error.message}\nStack: ${error.stack}\nURL: ${page.url()}`);
  }
  
  return filepath;
};

export default {
  captureAndSave,
  captureError,
  ensureOutputDir,
  generateFilename
};
// src/utils/wait.js
import { automationConfig } from '../config/index.js';
import logger from './logger.js';

/**
 * Aguarda um tempo determinado em ms
 */
export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Aguarda com retry até uma condição ser verdadeira
 */
export const waitForCondition = async (conditionFn, timeout, interval = 500, description = 'condição') => {
  const start = Date.now();
  
  while (Date.now() - start < timeout) {
    if (await conditionFn()) {
      return true;
    }
    await sleep(interval);
  }
  
  throw new Error(`Timeout aguardando: ${description}`);
};

/**
 * Wrapper inteligente para page.waitForSelector com retry
 */
export const waitForSelectorWithRetry = async (page, selector, options = {}) => {
  const {
    timeout = automationConfig.elementWaitTimeout,
    maxRetries = automationConfig.maxRetries,
    visible = true,
    module = 'wait'
  } = options;
  
  let lastError;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      logger.debug(module, `Tentativa ${attempt}/${maxRetries} para selector: ${selector}`);
      
      await page.waitForSelector(selector, { 
        timeout, 
        visible,
        ...options 
      });
      
      logger.debug(module, `✅ Selector encontrado: ${selector}`);
      return true;
      
    } catch (error) {
      lastError = error;
      logger.warn(module, `Falha na tentativa ${attempt}: ${error.message}`);
      
      if (attempt < maxRetries) {
        await sleep(automationConfig.retryDelay);
      }
    }
  }
  
  logger.error(module, `❌ Selector não encontrado após ${maxRetries} tentativas: ${selector}`);
  throw lastError;
};

/**
 * Aguarda navegação com fallback para timeout
 */
export const waitForNavigationSafe = async (page, actionFn, options = {}) => {
  const { timeout = automationConfig.defaultTimeout } = options;
  
  try {
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'networkidle2', timeout }),
      actionFn()
    ]);
  } catch (error) {
    // Fallback: espera um tempo e verifica se a URL mudou
    await sleep(2000);
    logger.warn('navigation', 'Navegação padrão falhou, usando fallback');
  }
};

export default {
  sleep,
  waitForCondition,
  waitForSelectorWithRetry,
  waitForNavigationSafe
};
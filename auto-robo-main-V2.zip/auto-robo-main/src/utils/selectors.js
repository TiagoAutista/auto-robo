// src/utils/selectors.js
// Centraliza todos os seletores CSS para fácil manutenção

export default {
  // ===== GOI - Login =====
  goi: {
    login: {
      email: 'input[name="logarLogin"]',
      password: 'input[name="logarSenha"]',
      submit: '#btn-autenticar',
      captchaContainer: '.captcha-box, #captcha, [id*="captcha"]'
    },
    
    home: {
      indicator: '.home-dashboard, #menu-principal',
      urlPattern: /goi\.vivo\.com\.br\/home/
    },
    
    agendamento: {
      url: /agendamento\/atendimento\.php/,
      tabs: {
        injecao: '#pills-injecao-tab',
        injecaoActive: '#pills-injecao-tab.active'
      },
      table: {
        container: 'table tbody',
        row: 'table tbody tr',
        cell: 'table tbody tr td'
      },
      actions: {
        atribuir: 'button[onclick*="atribuir"], .btn-atribuir, [data-action="atribuir"]',
        detalhes: '.btn-detalhes, [data-action="detalhes"]'
      }
    }
  },
  
  // ===== WFM =====
  wfm: {
    login: {
      username: 'input[name="username"], #username',
      password: 'input[name="password"], #password',
      submit: 'button[type="submit"], #btn-login'
    },
    workOrder: {
      container: '.work-order-details, #detalhes-wo',
      status: '.status-badge, [data-field="status"]'
    }
  },
  
  // ===== GPS =====
  gps: {
    login: {
      form: '#loginForm, form[name="login"]',
      submit: 'input[type="submit"], button.login'
    }
  },
  
  // ===== Genéricos =====
  common: {
    loading: '.loading, .spinner, [class*="loader"]',
    modal: '.modal, [role="dialog"], #modal',
    alert: '.alert, .toast, [role="alert"]',
    error: '.error, .error-message, [class*="erro"]'
  }
};
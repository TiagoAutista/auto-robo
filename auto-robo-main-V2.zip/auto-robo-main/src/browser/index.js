// src/browser/index.js
import puppeteer from 'puppeteer';
import { puppeteerConfig } from '../config/index.js';
import logger from '../utils/logger.js';
import { setupPage } from './utils.js';

/**
 * Conecta ou lança o navegador conforme configuração
 */
export const initBrowser = async () => {
  logger.info('browser', `Iniciando navegador (modo: ${puppeteerConfig.usarChromeExistente ? 'conectar' : 'lançar'})`);
  
  let browser;
  
  try {
    if (puppeteerConfig.usarChromeExistente) {
      // 🔌 Modo: Conectar ao Chrome existente via CDP
      logger.info('browser', `🔌 Conectando a: ${puppeteerConfig.debugUrl}`);
      browser = await puppeteer.connect(puppeteerConfig.getConnectOptions());
      logger.success('Conectado ao Chrome existente!');
      
    } else {
      // 🚀 Modo: Lançar novo Chrome gerenciado pelo Puppeteer
      logger.info('browser', '🚀 Lançando novo Chrome...');
      const launchOptions = puppeteerConfig.getLaunchOptions();
      
      if (puppeteerConfig.debug) {
        logger.debug('browser', 'Opções de launch:', JSON.stringify(launchOptions, null, 2));
      }
      
      browser = await puppeteer.launch(launchOptions);
      logger.success('Chrome iniciado!');
    }
    
    // Configura a primeira página disponível
    const pages = await browser.pages();
    const page = pages[0] || await browser.newPage();
    await setupPage(page);
    
    return { browser, page };
    
  } catch (error) {
    logger.error('browser', `Falha ao iniciar navegador: ${error.message}`, error);
    
    // Dicas de troubleshooting
    if (puppeteerConfig.usarChromeExistente) {
      logger.error('browser', '💡 Verifique:');
      logger.error('browser', '   1. Chrome está aberto com --remote-debugging-port=9222');
      logger.error('browser', '   2. CHROME_DEBUG_URL está correto no .env');
      logger.error('browser', '   3. Nenhuma outra instância está usando a porta');
    } else {
      logger.error('browser', '💡 Verifique:');
      logger.error('browser', '   1. Permissões de execução do Puppeteer');
      logger.error('browser', '   2. Antivírus/firewall não bloqueando');
      logger.error('browser', '   3. Espaço em disco suficiente para o Chrome');
    }
    
    throw error;
  }
};

/**
 * Fecha o navegador com segurança
 * (Não fecha se estiver conectado a Chrome existente)
 */
export const closeBrowser = async (browser) => {
  if (!browser) return;
  
  try {
    if (puppeteerConfig.usarChromeExistente) {
      // Apenas desconecta, não fecha o Chrome do usuário
      await browser.disconnect();
      logger.info('browser', '🔌 Desconectado do Chrome');
    } else {
      // Fecha o navegador gerenciado
      await browser.close();
      logger.info('browser', '🔒 Navegador fechado');
    }
  } catch (error) {
    logger.warn('browser', `Aviso ao fechar navegador: ${error.message}`);
  }
};

export default {
  initBrowser,
  closeBrowser
};
// src/browser/utils.js
import logger from '../utils/logger.js';
import { waitForSelectorWithRetry } from '../utils/wait.js';

/**
 * Configura viewport e comportamento padrão da página
 */
export const setupPage = async (page) => {
  await page.setViewport({ width: 1366, height: 768 });
  
  // Interceptar requests para otimizar
  await page.setRequestInterception(true);
  page.on('request', (req) => {
    // Bloqueia recursos desnecessários para acelerar
    if (['image', 'stylesheet', 'font'].includes(req.resourceType())) {
      if (req.url().includes('analytics') || req.url().includes('tracking')) {
        return req.abort();
      }
    }
    req.continue();
  });
  
  logger.debug('browser', 'Página configurada com viewport e interceptação');
  return page;
};

/**
 * Aguarda página estar completamente carregada
 */
export const waitForPageReady = async (page, timeout = 30000) => {
  await page.waitForFunction(
    () => document.readyState === 'complete',
    { timeout }
  );
  logger.debug('browser', 'Página pronta (readyState: complete)');
};

/**
 * Verifica se elemento está visível e clicável
 */
export const isElementReady = async (page, selector) => {
  try {
    await waitForSelectorWithRetry(page, selector, { visible: true, timeout: 5000 });
    return true;
  } catch {
    return false;
  }
};

/**
 * Clique seguro com verificação prévia
 */
export const safeClick = async (page, selector, options = {}) => {
  const { timeout = 10000, delay = 0 } = options;
  
  await waitForSelectorWithRetry(page, selector, { timeout });
  
  if (delay > 0) {
    await new Promise(r => setTimeout(r, delay));
  }
  
  await page.click(selector);
  logger.debug('browser', `✅ Clique em: ${selector}`);
};

/**
 * Preenche campo com delay entre teclas (mais humano)
 */
export const humanType = async (page, selector, text, options = {}) => {
  const { delay = 30, clear = true } = options;
  
  await waitForSelectorWithRetry(page, selector);
  
  if (clear) {
    await page.click(selector, { clickCount: 3 }); // Seleciona tudo
    await page.keyboard.press('Delete');
  }
  
  await page.type(selector, text, { delay });
  logger.debug('browser', `✅ Digitado em ${selector}: ${'*'.repeat(text.length)}`);
};

export default {
  setupPage,
  waitForPageReady,
  isElementReady,
  safeClick,
  humanType
};
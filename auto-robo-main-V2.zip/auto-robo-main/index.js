// index.js - Entry Point do Auto Robô v2.0
import { initBrowser, closeBrowser } from './src/browser/index.js';
import { loginService, injectionService, navigationService } from './src/index.js';
import { logger, automationConfig, systemsConfig } from './src/index.js';
import { captureAndSave } from './src/utils/screenshots.js';
import { sleep } from './src/utils/wait.js';

console.log('🤖 [ROBÔ] Processo iniciado via Dashboard...');

const runAutomation = async () => {
  let browser = null;
  let page = null;

  try {
    logger.info('main', '🚀 Iniciando automação...');
    
    // 1. Inicializa navegador
    const { browser: br, page: pg } = await initBrowser();
    browser = br;
    page = pg;

    // 2. Login no GOI
    logger.info('main', '🔐 Etapa 1: Login no GOI');
    await loginService.loginGOI(page);
    await sleep(1000);

    // 3. Login no WFM (se habilitado)
    if (systemsConfig.abrirWFM) {
      logger.info('main', '🔐 Etapa 2: Login no WFM');
      await loginService.loginWFM(page);
      await sleep(1000);
    }

    // 4. Abre abas adicionais
    logger.info('main', '🗂️ Etapa 3: Abrindo abas adicionais');
    await navigationService.openSystemTabs(browser, page);

    // 5. Executa Injeção D0
    logger.info('main', '💉 Etapa 4: Executando Injeção D0');
    await injectionService.executarInjecaoD0(page);

    // 6. Busca e atribui atividade (se configurado)
    if (automationConfig.atividadeTeste) {
      logger.info('main', '🎯 Etapa 5: Buscando atividade de teste');
      await injectionService.buscarEAtribuirAtividade(page, automationConfig.atividadeTeste);
    }

    // 7. Screenshot final
    await captureAndSave(page, 'conclusao');
    logger.success('main', '✅ Automação concluída com sucesso!');

  } catch (error) {
    logger.error('main', `❌ Erro crítico: ${error.message}`, error);
    if (page) await captureAndSave(page, 'erro_critico');
    process.exitCode = 1;
  } finally {
    if (browser) {
      logger.info('main', '🔒 Finalizando navegador...');
      await closeBrowser(browser);
    }
    logger.info('main', '🔚 Processo do robô encerrado.');
  }
};

// 🟢 EXECUTA SEMPRE AO SER CHAMADO (sem condições frágeis)
runAutomation().catch(err => {
  console.error('💥 Erro fatal não tratado:', err);
  process.exit(1);
});
// scripts/mock-server.js
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const app = express();
const PORT = 3456;

// Middleware para parsear JSON e forms
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ===== MOCK: Página de Login GOI =====
app.get('/login', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head><title>GOI - Login</title></head>
    <body>
      <form id="loginForm">
        <input name="logarLogin" placeholder="Usuário" />
        <input name="logarSenha" type="password" placeholder="Senha" />
        <button id="btn-autenticar" type="submit">Entrar</button>
      </form>
      <script>
        document.getElementById('loginForm').addEventListener('submit', (e) => {
          e.preventDefault();
          window.location.href = '/home/index.php';
        });
      </script>
    </body>
    </html>
  `);
});

// ===== MOCK: Home GOI =====
app.get('/home/index.php', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head><title>GOI - Home</title></head>
    <body>
      <div id="menu-principal">
        <a href="/agendamento/atendimento.php">Agendamento</a>
      </div>
      <h1>Bem-vindo ao GOI</h1>
    </body>
    </html>
  `);
});

// ===== MOCK: Agendamento =====
app.get('/agendamento/atendimento.php', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head><title>Agendamento</title></head>
    <body>
      <ul class="nav nav-pills">
        <li><a id="pills-injecao-tab" href="#" onclick="activateTab(this)">Injeção D0</a></li>
      </ul>
      
      <div id="pills-injecao" class="tab-pane active">
        <table>
          <tbody>
            <tr data-id="7391517763">
              <td>7391517763</td>
              <td>Atividade Teste</td>
              <td><button class="btn-atribuir" onclick="atribuir('7391517763')">Atribuir</button></td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <script>
        // Simula a função real do sistema
        function injecaoAnalitico(status, tipo, origem) {
          console.log('injecaoAnalitico chamado:', {status, tipo, origem});
          document.querySelector('table tbody').style.display = 'table-row-group';
        }
        
        function activateTab(el) {
          document.querySelectorAll('.nav-pills a').forEach(a => a.classList.remove('active'));
          el.classList.add('active');
        }
        
        function atribuir(id) {
          alert('Atividade ' + id + ' atribuída!');
        }
      </script>
    </body>
    </html>
  `);
});

// Inicia servidor
app.listen(PORT, () => {
  console.log(`🎭 Mock server rodando em http://localhost:${PORT}`);
  console.log(`📍 Endpoints disponíveis:`);
  console.log(`   GET  /login`);
  console.log(`   GET  /home/index.php`);
  console.log(`   GET  /agendamento/atendimento.php`);
});
// scripts/test-puppeteer.js
import { initBrowser, closeBrowser } from '../src/browser/index.js';
import logger from '../src/utils/logger.js';
import { captureAndSave } from '../src/utils/screenshots.js';

console.log('🧪 Teste Básico do Puppeteer\n');

(async () => {
  let browser = null;
  
  try {
    // Inicia navegador
    const { browser: br, page } = await initBrowser();
    browser = br;
    
    logger.success('Navegador inicializado!');
    
    // Navega para página de teste
    logger.info('test', '🌐 Acessando https://httpbin.org/ip');
    await page.goto('https://httpbin.org/ip', { waitUntil: 'networkidle2' });
    
    // Extrai conteúdo
    const content = await page.content();
    logger.debug('test', `Página carregada (${content.length} caracteres)`);
    
    // Tira screenshot
    await captureAndSave(page, 'test-puppeteer');
    
    logger.success('✅ Teste concluído com sucesso!');
    
  } catch (error) {
    logger.error('test', `❌ Falha no teste: ${error.message}`, error);
    process.exitCode = 1;
    
  } finally {
    if (browser) {
      await closeBrowser(browser);
    }
    process.exit(process.exitCode || 0);
  }
})();
// validar-env.js
import dotenv from 'dotenv';
import { existsSync } from 'fs';
dotenv.config();

console.log('🔍 Validando .env...\n');

const checks = [
  { name: 'USAR_CHROME_EXISTENTE', value: process.env.USAR_CHROME_EXISTENTE, required: true },
  { name: 'HEADLESS', value: process.env.HEADLESS, required: true },
  { name: 'LOGIN_URL', value: process.env.LOGIN_URL, required: true },
  { name: 'LOGIN_EMAIL', value: process.env.LOGIN_EMAIL, required: true },
];

if (process.env.USAR_CHROME_EXISTENTE === 'true') {
  checks.push(
    { name: 'CHROME_DEBUG_URL', value: process.env.CHROME_DEBUG_URL, required: true }
  );
} else {
  checks.push(
    { name: 'CHROME_PATH', value: process.env.CHROME_PATH, required: false, hint: 'Opcional: Puppeteer usa Chrome gerenciado' }
  );
}

let ok = true;
for (const check of checks) {
  const status = check.required 
    ? (check.value ? '✅' : '❌') 
    : (check.value ? '✅' : '⚪');
  
  if (check.required && !check.value) ok = false;
  
  console.log(`${status} ${check.name}: ${check.value || '(não definido)'}`);
  if (check.hint && !check.value) console.log(`   💡 ${check.hint}`);
}

console.log(ok ? '\n✨ .env válido!' : '\n❌ Corrija os itens marcados com ❌');
/**
 * AUTO ROBO - Frontend Controller
 * Dashboard Web com WebSocket e API
 */

// ============================================================================
// CONFIGURAÇÃO E ESTADO
// ============================================================================

const CONFIG = {
    apiBase: '/api',
    wsReconnectDelay: 3000,
    maxLogEntries: 200,
    autoScroll: true
};

const state = {
    socket: null,
    isRunning: false,
    currentActivity: null,
    reconnectAttempts: 0,
    logsBuffer: []
};

// Cache de elementos DOM
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

const elements = {
    // Status
    statusBadge: $('#statusBadge'),
    statusText: $('.status-text'),
    statusDot: $('.status-dot'),
    
    // Stats
    totalProcessed: $('#totalProcessed'),
    successCount: $('#successCount'),
    failCount: $('#failCount'),
    uptime: $('#uptime'),
    
    // Controls
    atividadeId: $('#atividadeId'),
    loteAtividades: $('#loteAtividades'),
    btnStart: $('#btnStart'),
    btnStop: $('#btnStop'),
    btnBatch: $('#btnBatch'),
    chkWFM: $('#chkWFM'),
    chkGPS: $('#chkGPS'),
    
    // Logs
    logsContainer: $('#logsContainer'),
    btnClearLogs: $('#btnClearLogs')
};

// ============================================================================
// INICIALIZAÇÃO
// ============================================================================

document.addEventListener('DOMContentLoaded', () => {
    initWebSocket();
    initEventListeners();
    loadInitialStatus();
    setupKeyboardShortcuts();
    
    console.log('🤖 Auto Robo Dashboard carregado');
});

function initWebSocket() {
    // Conectar ao WebSocket
    state.socket = io({
        reconnection: true,
        reconnectionDelay: CONFIG.wsReconnectDelay,
        reconnectionAttempts: 10
    });
    
    // Event listeners do socket
    state.socket.on('connect', onSocketConnect);
    state.socket.on('disconnect', onSocketDisconnect);
    state.socket.on('connect_error', onSocketError);
    state.socket.on('status', onStatusUpdate);
    state.socket.on('log', onNewLog);
    state.socket.on('logs', onLogsBatch);
    
    // Cleanup on unload
    window.addEventListener('beforeunload', () => {
        if (state.socket?.connected) {
            state.socket.disconnect();
        }
    });
}

function initEventListeners() {
    // Botões principais
    elements.btnStart?.addEventListener('click', startAutomation);
    elements.btnStop?.addEventListener('click', stopAutomation);
    elements.btnBatch?.addEventListener('click', startBatch);
    elements.btnClearLogs?.addEventListener('click', clearLogs);
    
    // Enter no campo de atividade
    elements.atividadeId?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !state.isRunning) {
            startAutomation();
        }
    });
    
    // Ctrl+Enter no textarea do lote
    elements.loteAtividades?.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'Enter' && !state.isRunning) {
            e.preventDefault();
            startBatch();
        }
    });
    
    // Atualizar estado dos checkboxes
    elements.chkWFM?.addEventListener('change', savePreferences);
    elements.chkGPS?.addEventListener('change', savePreferences);
    
    // Auto-scroll dos logs
    elements.logsContainer?.addEventListener('scroll', () => {
        const { scrollTop, scrollHeight, clientHeight } = elements.logsContainer;
        CONFIG.autoScroll = scrollTop + clientHeight >= scrollHeight - 50;
    });
}

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // Ctrl+1: Focar campo de atividade
        if (e.ctrlKey && e.key === '1') {
            e.preventDefault();
            elements.atividadeId?.focus();
        }
        
        // Ctrl+2: Focar textarea do lote
        if (e.ctrlKey && e.key === '2') {
            e.preventDefault();
            elements.loteAtividades?.focus();
        }
        
        // Ctrl+R: Recarregar página (com confirmação se rodando)
        if (e.ctrlKey && e.key === 'r' && state.isRunning) {
            e.preventDefault();
            if (confirm('⚠️ Automação em execução. Deseja realmente recarregar?')) {
                location.reload();
            }
        }
        
        // Escape: Parar automação
        if (e.key === 'Escape' && state.isRunning) {
            e.preventDefault();
            stopAutomation();
        }
    });
}

// ============================================================================
// WEBSOCKET HANDLERS
// ============================================================================

function onSocketConnect() {
    console.log('🔌 Conectado ao servidor');
    state.reconnectAttempts = 0;
    addLog('info', '✅ Conectado ao servidor');
    updateConnectionStatus(true);
}

function onSocketDisconnect(reason) {
    console.log('🔌 Desconectado:', reason);
    addLog('warning', `⚠️ Desconectado: ${reason}`);
    updateConnectionStatus(false);
}

function onSocketError(error) {
    console.error('❌ Erro de conexão:', error);
    addLog('error', `❌ Erro de conexão: ${error.message}`);
    
    // Tentar reconectar manualmente se necessário
    if (state.reconnectAttempts < 5) {
        state.reconnectAttempts++;
        setTimeout(() => {
            console.log(`🔄 Tentativa de reconexão ${state.reconnectAttempts}/5`);
            state.socket.connect();
        }, CONFIG.wsReconnectDelay * state.reconnectAttempts);
    }
}

function onStatusUpdate(status) {
    updateUIStatus(status);
}

function onNewLog(log) {
    addLogEntry(log);
}

function onLogsBatch(logs) {
    // Limpar e adicionar logs em batch
    elements.logsContainer.innerHTML = '';
    logs.forEach(log => addLogEntry(log, false));
    scrollToBottom();
}

// ============================================================================
// API CALLS
// ============================================================================

async function apiRequest(endpoint, options = {}) {
    const url = `${CONFIG.apiBase}${endpoint}`;
    const config = {
        headers: { 'Content-Type': 'application/json', ...options.headers },
        ...options
    };
    
    if (options.body && typeof options.body === 'object') {
        config.body = JSON.stringify(options.body);
    }
    
    try {
        const response = await fetch(url, config);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || `HTTP ${response.status}`);
        }
        
        return data;
    } catch (error) {
        console.error(`❌ API Error (${endpoint}):`, error);
        addLog('error', `❌ API: ${error.message}`);
        throw error;
    }
}

async function loadInitialStatus() {
    try {
        const status = await apiRequest('/status');
        updateUIStatus(status);
        
        // Carregar configurações
        const config = await apiRequest('/config');
        if (config) {
            elements.chkWFM.checked = config.abrirWFM !== false;
            elements.chkGPS.checked = config.abrirGPS !== false;
        }
    } catch (error) {
        console.warn('⚠️ Não foi possível carregar status inicial');
    }
}

async function startAutomation() {
    const atividadeId = elements.atividadeId?.value.trim();
    
    if (!atividadeId) {
        showToast('⚠️ Digite o ID da atividade!', 'warning');
        elements.atividadeId?.focus();
        return;
    }
    
    // Validar formato (opcional)
    if (!/^\d+$/.test(atividadeId)) {
        if (!confirm('⚠️ ID parece inválido. Continuar mesmo assim?')) {
            return;
        }
    }
    
    setLoading(elements.btnStart, true);
    
    try {
        await apiRequest('/start', {
            method: 'POST',
            body: { atividadeId }
        });
        
        addLog('success', `🚀 Automação iniciada: ${atividadeId}`);
        elements.atividadeId.value = '';
        showToast('✅ Automação iniciada!', 'success');
        
    } catch (error) {
        showToast(`❌ ${error.message}`, 'error');
    } finally {
        setLoading(elements.btnStart, false);
    }
}

async function stopAutomation() {
    if (!confirm('🛑 Deseja parar a automação em execução?')) {
        return;
    }
    
    setLoading(elements.btnStop, true);
    
    try {
        await apiRequest('/stop', { method: 'POST' });
        addLog('warning', '🛑 Automação parada pelo usuário');
        showToast('⏹️ Automação parada', 'info');
    } catch (error) {
        showToast(`❌ ${error.message}`, 'error');
    } finally {
        setLoading(elements.btnStop, false);
    }
}

async function startBatch() {
    const texto = elements.loteAtividades?.value.trim();
    
    if (!texto) {
        showToast('⚠️ Digite as atividades!', 'warning');
        elements.loteAtividades?.focus();
        return;
    }
    
    const atividades = texto
        .split('\n')
        .map(l => l.trim())
        .filter(l => l && !l.startsWith('#'));
    
    if (atividades.length === 0) {
        showToast('⚠️ Nenhuma atividade válida encontrada!', 'warning');
        return;
    }
    
    if (!confirm(`📦 Processar ${atividades.length} atividades?`)) {
        return;
    }
    
    setLoading(elements.btnBatch, true);
    
    try {
        await apiRequest('/batch', {
            method: 'POST',
            body: { atividades }
        });
        
        addLog('success', `📦 Lote iniciado: ${atividades.length} atividades`);
        elements.loteAtividades.value = '';
        showToast(`✅ Lote de ${atividades.length} iniciado!`, 'success');
        
    } catch (error) {
        showToast(`❌ ${error.message}`, 'error');
    } finally {
        setLoading(elements.btnBatch, false);
    }
}

// ============================================================================
// UI UPDATES
// ============================================================================

function updateUIStatus(status) {
    state.isRunning = status.isRunning;
    state.currentActivity = status.currentActivity;
    
    // Atualizar stats
    animateNumber(elements.totalProcessed, status.totalProcessed);
    animateNumber(elements.successCount, status.successCount);
    animateNumber(elements.failCount, status.failCount);
    elements.uptime.textContent = formatUptime(status.uptime);
    
    // Atualizar badge de status
    updateStatusBadge(status.currentStatus);
    
    // Atualizar botões
    elements.btnStart.disabled = state.isRunning;
    elements.btnStop.disabled = !state.isRunning;
    elements.btnBatch.disabled = state.isRunning;
    
    // Atualizar título da página
    document.title = state.isRunning 
        ? `🔄 ${status.currentActivity || 'Rodando'} - Auto Robo`
        : '🤖 Auto Robo - Dashboard';
}

function updateStatusBadge(status) {
    const statusMap = {
        idle: { text: 'Aguardando', class: 'idle', color: 'var(--text-secondary)' },
        running: { text: 'Em Execução', class: 'running', color: 'var(--success)' },
        starting: { text: 'Iniciando...', class: 'running', color: 'var(--info)' },
        searching: { text: 'Buscando...', class: 'running', color: 'var(--info)' },
        assigning: { text: 'Atribuindo...', class: 'running', color: 'var(--info)' },
        extracting: { text: 'Extraindo...', class: 'running', color: 'var(--info)' },
        opening_wfm: { text: 'Abrindo WFM...', class: 'running', color: 'var(--neon-purple)' },
        opening_gps: { text: 'Abrindo GPS...', class: 'running', color: 'var(--neon-purple)' },
        batch_processing: { text: 'Processando Lote...', class: 'running', color: 'var(--neon-purple)' },
        completed: { text: 'Concluído ✓', class: 'idle', color: 'var(--success)' },
        stopped: { text: 'Parado', class: 'stopped', color: 'var(--warning)' },
        error: { text: 'Erro ✗', class: 'error', color: 'var(--danger)' }
    };
    
    const config = statusMap[status] || statusMap.idle;
    
    elements.statusText.textContent = config.text;
    elements.statusBadge.className = `status-badge ${config.class}`;
    elements.statusDot.style.color = config.color;
    
    // Efeito visual para status running
    if (config.class === 'running') {
        elements.statusBadge.classList.add('status-running');
    } else {
        elements.statusBadge.classList.remove('status-running');
    }
}

function updateConnectionStatus(connected) {
    if (!connected) {
        elements.statusText.textContent = 'Desconectado...';
        elements.statusDot.style.background = 'var(--danger)';
        elements.statusDot.style.color = 'var(--danger)';
    }
}

function addLogEntry(log, shouldScroll = true) {
    if (!elements.logsContainer) return;
    
    const entry = document.createElement('div');
    entry.className = `log-entry ${log.type}`;
    entry.dataset.timestamp = log.timestamp;
    
    const time = new Date(log.timestamp).toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    
    // Format message with icons
    let message = log.message;
    const icons = {
        '🚀': 'info', '✅': 'success', '⚠️': 'warning', '❌': 'error',
        '🔍': 'info', '📄': 'info', '🔧': 'info', '🌐': 'info', '🎉': 'success'
    };
    
    for (const [icon, type] of Object.entries(icons)) {
        if (log.type === type && !message.startsWith(icon)) {
            message = message.replace(/^[🚀✅⚠️❌🔍📄🔧🌐🎉]\s*/, '');
            break;
        }
    }
    
    entry.innerHTML = `
        <span class="log-timestamp">${time}</span>
        <span class="log-message">${escapeHtml(message)}</span>
    `;
    
    elements.logsContainer.appendChild(entry);
    
    // Limitar número de logs
    const logs = elements.logsContainer.querySelectorAll('.log-entry');
    if (logs.length > CONFIG.maxLogEntries) {
        logs[0].remove();
    }
    
    // Auto-scroll
    if (shouldScroll && CONFIG.autoScroll) {
        scrollToBottom();
    }
}

function addLog(type, message) {
    const log = {
        timestamp: new Date().toISOString(),
        type,
        message
    };
    addLogEntry(log);
}

function clearLogs() {
    if (!confirm('🧹 Limpar todos os logs?')) return;
    
    elements.logsContainer.innerHTML = '';
    addLog('info', '🧹 Logs limpos pelo usuário');
    showToast('🗑️ Logs limpos', 'info');
}

// ============================================================================
// UTILITÁRIOS
// ============================================================================

function animateNumber(element, target, duration = 500) {
    if (!element) return;
    
    const start = parseInt(element.textContent) || 0;
    if (start === target) return;
    
    const startTime = performance.now();
    
    function update(currentTime) {
        const progress = Math.min((currentTime - startTime) / duration, 1);
        const easeProgress = 1 - Math.pow(1 - progress, 3); // Ease out cubic
        const current = Math.round(start + (target - start) * easeProgress);
        
        element.textContent = current;
        
        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }
    
    requestAnimationFrame(update);
}

function formatUptime(ms) {
    if (!ms) return '0s';
    const seconds = Math.floor(ms / 1000);
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${mins}m`;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type = 'info', duration = 4000) {
    // Criar toast se não existir
    let toast = document.getElementById('toast-container');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast-container';
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 400px;
        `;
        document.body.appendChild(toast);
    }
    
    const colors = {
        info: 'var(--info)',
        success: 'var(--success)',
        warning: 'var(--warning)',
        error: 'var(--danger)'
    };
    
    const icons = {
        info: 'ℹ️',
        success: '✅',
        warning: '⚠️',
        error: '❌'
    };
    
    const toastEl = document.createElement('div');
    toastEl.style.cssText = `
        padding: 15px 20px;
        background: var(--card-bg);
        border: 1px solid ${colors[type]};
        border-left: 4px solid ${colors[type]};
        border-radius: 12px;
        color: var(--text-primary);
        box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        animation: slideInRight 0.3s ease, fadeOut 0.3s ease ${duration - 300}ms forwards;
        display: flex;
        align-items: center;
        gap: 12px;
        font-weight: 500;
    `;
    
    toastEl.innerHTML = `
        <span style="font-size: 1.2rem">${icons[type]}</span>
        <span>${escapeHtml(message)}</span>
    `;
    
    toast.appendChild(toastEl);
    
    // Remover após animação
    setTimeout(() => toastEl.remove(), duration);
}

function setLoading(button, loading) {
    if (!button) return;
    
    if (loading) {
        button.classList.add('loading');
        button.dataset.originalText = button.innerHTML;
    } else {
        button.classList.remove('loading');
    }
}

function scrollToBottom() {
    if (elements.logsContainer) {
        elements.logsContainer.scrollTop = elements.logsContainer.scrollHeight;
    }
}

function savePreferences() {
    // Salvar preferências no localStorage
    const prefs = {
        abrirWFM: elements.chkWFM?.checked,
        abrirGPS: elements.chkGPS?.checked
    };
    localStorage.setItem('autoRobo_prefs', JSON.stringify(prefs));
    
    // Opcional: enviar para o backend
    // apiRequest('/config', { method: 'POST', body: prefs }).catch(() => {});
}

function loadPreferences() {
    try {
        const prefs = JSON.parse(localStorage.getItem('autoRobo_prefs') || '{}');
        if (prefs.abrirWFM !== undefined) elements.chkWFM.checked = prefs.abrirWFM;
        if (prefs.abrirGPS !== undefined) elements.chkGPS.checked = prefs.abrirGPS;
    } catch (e) {
        console.warn('⚠️ Não foi possível carregar preferências');
    }
}

// Animations CSS injection
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes fadeOut {
        from { opacity: 1; transform: translateX(0); }
        to { opacity: 0; transform: translateX(100%); }
    }
`;
document.head.appendChild(style);

// Load preferences on init
loadPreferences();
/**
 * Automação com Puppeteer
 */

import puppeteer from 'puppeteer';
import dotenv from 'dotenv';

dotenv.config();

const CONFIG = {
    chromeDebugUrl: process.env.CHROME_DEBUG_URL || 'http://localhost:9222',
    loginUrl: process.env.LOGIN_URL,
    agendamentoUrl: process.env.AGENDAMENTO_URL,
    wfmUrl: process.env.WFM_URL,
    gpsUrl: process.env.GPS_URL,
    loginEmail: process.env.LOGIN_EMAIL,
    loginPassword: process.env.LOGIN_PASSWORD,
    abrirWFM: process.env.ABRIR_WFM !== 'false',
    abrirGPS: process.env.ABRIR_GPS !== 'false'
};

export const iniciarAutomacao = async () => {
    try {
        // Tentar conectar ao Chrome existente
        if (process.env.USAR_CHROME_EXISTENTE === 'true') {
            try {
                const browser = await puppeteer.connect({
                    browserURL: CONFIG.chromeDebugUrl,
                    defaultViewport: { width: 1920, height: 1080 }
                });
                const pages = await browser.pages();
                const page = pages[0] || await browser.newPage();
                return { browser, page };
            } catch (err) {
                console.log('⚠️ Não conectou ao Chrome. Iniciando novo...');
            }
        }
        
        // Lançar novo Chrome
        const browser = await puppeteer.launch({
            headless: false,
            args: ['--no-sandbox', '--disable-dev-shm-usage', '--remote-debugging-port=9222']
        });
        const page = await browser.newPage();
        return { browser, page };
        
    } catch (error) {
        throw new Error(`Erro ao iniciar navegador: ${error.message}`);
    }
};

export const realizarLogin = async (page, logCallback) => {
    try {
        logCallback({ type: 'info', message: '🔐 Acessando login...' });
        await page.goto(CONFIG.loginUrl, { waitUntil: 'networkidle2', timeout: 60000 });
        
        await page.waitForSelector('input[name="logarLogin"]', { visible: true });
        await page.type('input[name="logarLogin"]', CONFIG.loginEmail, { delay: 50 });
        await page.type('input[name="logarSenha"]', CONFIG.loginPassword, { delay: 50 });
        
        logCallback({ type: 'info', message: '✅ Campos preenchidos. Resolva CAPTCHA...' });
        
        // Aguarda usuário resolver CAPTCHA e clicar login manualmente
        await page.waitForNavigation({ waitUntil: 'networkidle0', timeout: 120000 });
        
        logCallback({ type: 'success', message: '✅ Login realizado!' });
        return true;
        
    } catch (error) {
        logCallback({ type: 'error', message: `❌ Login falhou: ${error.message}` });
        return false;
    }
};

export const navegarParaAgendamento = async (page, logCallback) => {
    try {
        logCallback({ type: 'info', message: '🗓️  Navegando para agendamento...' });
        await page.goto(CONFIG.agendamentoUrl, { waitUntil: 'networkidle2' });
        
        logCallback({ type: 'info', message: '💉 Acessando aba Injeção D0...' });
        await page.waitForSelector('#pills-injecao-tab', { visible: true });
        await page.click('#pills-injecao-tab');
        await page.waitForSelector('#tb-injecaoAnalitico', { visible: true });
        
        logCallback({ type: 'info', message: '⚙️  Carregando dados...' });
        await page.evaluate(() => {
            if (typeof injecaoAnalitico === 'function') {
                injecaoAnalitico('pendente', 'TODOS', 'atendimento');
            }
        });
        
        await page.waitForSelector('#tb-injecaoAnalitico tbody tr', { visible: true, timeout: 30000 });
        logCallback({ type: 'success', message: '✅ Página pronta!' });
        
    } catch (error) {
        logCallback({ type: 'error', message: `❌ Erro: ${error.message}` });
        throw error;
    }
};

export const buscarAtividade = async (page, atividadeId, logCallback) => {
    try {
        logCallback({ type: 'info', message: `🔎 Buscando ${atividadeId}...` });
        
        // Tentar filtro de busca
        await page.waitForSelector('input[aria-controls="tb-injecaoAnalitico"]', { visible: true });
        await page.$eval('input[aria-controls="tb-injecaoAnalitico"]', el => { el.value = ''; el.dispatchEvent(new Event('input')); });
        await page.type('input[aria-controls="tb-injecaoAnalitico"]', atividadeId, { delay: 30 });
        
        await new Promise(r => setTimeout(r, 1000));
        
        const encontrado = await page.evaluate((id) => {
            const rows = document.querySelectorAll('#tb-injecaoAnalitico tbody tr');
            return Array.from(rows).some(row => 
                row.style.display !== 'none' && row.textContent.includes(id)
            );
        }, atividadeId);
        
        if (encontrado) {
            logCallback({ type: 'success', message: '✅ Atividade encontrada!' });
            return true;
        } else {
            logCallback({ type: 'error', message: '❌ Atividade não encontrada' });
            return false;
        }
        
    } catch (error) {
        logCallback({ type: 'error', message: `❌ Erro na busca: ${error.message}` });
        return false;
    }
};

export const atribuirAtividade = async (page, atividadeId, logCallback) => {
    try {
        logCallback({ type: 'info', message: '🎯 Atribuindo atividade...' });
        
        const resultado = await page.evaluate((id) => {
            const rows = document.querySelectorAll('#tb-injecaoAnalitico tbody tr');
            let linha = null;
            for (const row of rows) {
                if (row.style.display !== 'none' && row.textContent.includes(id)) {
                    linha = row;
                    break;
                }
            }
            if (!linha) return { sucesso: false, erro: 'Linha não encontrada' };
            
            // Tentar clicar no botão de atribuir
            const botoes = [
                `td[onclick*="${id}"]`, 'button[class*="atribuir"]', '*[onclick*="atribuir"]',
                'td[onclick]', 'button', 'a'
            ];
            
            for (const selector of botoes) {
                const btn = linha.querySelector(selector);
                if (btn) {
                    btn.click();
                    return { sucesso: true };
                }
            }
            
            return { sucesso: false, erro: 'Botão não encontrado' };
        }, atividadeId);
        
        if (resultado.sucesso) {
            logCallback({ type: 'success', message: '✅ Atividade atribuída!' });
            return true;
        } else {
            logCallback({ type: 'error', message: `❌ ${resultado.erro}` });
            return false;
        }
        
    } catch (error) {
        logCallback({ type: 'error', message: `❌ Erro: ${error.message}` });
        return false;
    }
};

export const extrairDocumento = async (page, atividadeId, logCallback) => {
    try {
        logCallback({ type: 'info', message: '📄 Extraindo documento...' });
        
        const documento = await page.evaluate((id) => {
            const rows = document.querySelectorAll('#tb-injecaoAnalitico tbody tr');
            for (const row of rows) {
                if (row.style.display !== 'none' && row.textContent.includes(id)) {
                    const label = row.querySelector('label[for="val_documento"]');
                    if (label) {
                        const texto = label.parentElement.textContent || '';
                        const partes = texto.split('Documento:').filter(p => p.trim());
                        if (partes.length > 0) {
                            return partes[0].trim().split(/\s+/)[0].replace(/[^\d.\-\/]/g, '');
                        }
                    }
                    // Fallback: regex CPF/CNPJ
                    const match = row.textContent.match(/\d{3}[.\-]?\d{3}[.\-]?\d{3}[.\-]?\d{2}/);
                    if (match) return match[0];
                }
            }
            return null;
        }, atividadeId);
        
        if (documento) {
            logCallback({ type: 'success', message: `✅ Documento: ${documento}` });
            return documento;
        } else {
            logCallback({ type: 'warning', message: '⚠️ Documento não encontrado' });
            return null;
        }
        
    } catch (error) {
        logCallback({ type: 'error', message: `❌ Erro: ${error.message}` });
        return null;
    }
};

export const abrirWFM = async (page, atividadeId, logCallback) => {
    try {
        const url = `${CONFIG.wfmUrl}?wo=${atividadeId}`;
        logCallback({ type: 'info', message: `🔧 Abrindo WFM...` });
        await page.evaluate((url) => window.open(url, '_blank'), url);
        logCallback({ type: 'success', message: '✅ WFM aberto!' });
        return true;
    } catch (error) {
        logCallback({ type: 'error', message: `❌ Erro: ${error.message}` });
        return false;
    }
};

export const abrirGPS = async (page, documento, logCallback) => {
    try {
        const url = `${CONFIG.gpsUrl}?documento=${encodeURIComponent(documento)}`;
        logCallback({ type: 'info', message: `🌐 Abrindo GPS...` });
        await page.evaluate((url) => window.open(url, '_blank'), url);
        logCallback({ type: 'success', message: '✅ GPS aberto!' });
        return true;
    } catch (error) {
        logCallback({ type: 'error', message: `❌ Erro: ${error.message}` });
        return false;
    }
};

export const processarAtividade = async (page, atividadeId, logCallback) => {
    try {
        // Verificar se já está na página correta
        const urlAtual = page.url();
        if (!urlAtual.includes('agendamento')) {
            await realizarLogin(page, logCallback);
            await navegarParaAgendamento(page, logCallback);
        }
        
        // Buscar e atribuir
        const encontrado = await buscarAtividade(page, atividadeId, logCallback);
        if (!encontrado) return { sucesso: false, erro: 'Não encontrada' };
        
        const atribuido = await atribuirAtividade(page, atividadeId, logCallback);
        if (!atribuido) return { sucesso: false, erro: 'Não atribuída' };
        
        // Extrair documento
        const documento = await extrairDocumento(page, atividadeId, logCallback);
        
        // Abrir sistemas externos
        if (CONFIG.abrirWFM) {
            await abrirWFM(page, atividadeId, logCallback);
        }
        
        if (CONFIG.abrirGPS && documento) {
            await abrirGPS(page, documento, logCallback);
        }
        
        return { sucesso: true, documento };
        
    } catch (error) {
        return { sucesso: false, erro: error.message };
    }
};

export const fecharNavegador = async (browser) => {
    try {
        if (browser) {
            if (process.env.USAR_CHROME_EXISTENTE === 'true') {
                await browser.disconnect();
            } else {
                await browser.close();
            }
        }
    } catch (error) {
        console.error('Erro ao fechar:', error.message);
    }
};

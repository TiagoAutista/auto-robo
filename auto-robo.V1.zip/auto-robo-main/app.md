# 1. Navegue até a pasta do projeto
cd C:\auto-robo-redecorp

# 2. Reinstale as dependências (garante compatibilidade)
npm install

# 3. Inicie o Chrome com debug (se usar Chrome existente)
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --user-data-dir="C:\chrome-puppeteer-profile"

# 4. Inicie o servidor
npm start

# 5. Acesse o dashboard
http://localhost:3000

// test-puppeteer.js
import puppeteer from 'puppeteer';
import dotenv from 'dotenv';
dotenv.config();

(async () => {
  console.log('🧪 Testando Puppeteer com Chrome gerenciado...\n');
  
  const browser = await puppeteer.launch({
    headless: process.env.HEADLESS === 'true' ? 'new' : false,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
    slowMo: 100
  });
  
  console.log('✅ Navegador iniciado!');
  console.log(`📦 Versão: ${await browser.version()}`);
  
  const page = await browser.newPage();
  await page.goto('https://httpbin.org/ip', { waitUntil: 'networkidle2' });
  
  const content = await page.content();
  console.log('🌐 Página carregada com sucesso!');
  
  await page.screenshot({ path: 'test-screenshot.png' });
  console.log('📸 Screenshot salvo: test-screenshot.png');
  
  await browser.close();
  console.log('\n✨ Teste concluído!');
})();
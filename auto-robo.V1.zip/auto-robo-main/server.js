/**
 * Servidor Web - Auto Robo Redecorp
 * Integra Express + Socket.io + Puppeteer
 */

import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { iniciarAutomacao, processarAtividade, fecharNavegador } from './automation.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: "*" } });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Estado da aplicação
const appState = {
    isRunning: false,
    currentActivity: null,
    totalProcessed: 0,
    successCount: 0,
    failCount: 0,
    status: 'idle',
    startTime: null,
    logs: [],
    browser: null,
    page: null
};

// Função para enviar logs
const emitLog = (type, message, data = null) => {
    const log = { timestamp: new Date().toISOString(), type, message, data };
    appState.logs.push(log);
    if (appState.logs.length > 100) appState.logs.shift();
    io.emit('log', log);
};

// ============================================================================
// ROTAS DA API
// ============================================================================

app.get('/api/status', (req, res) => {
    res.json({
        isRunning: appState.isRunning,
        currentActivity: appState.currentActivity,
        totalProcessed: appState.totalProcessed,
        successCount: appState.successCount,
        failCount: appState.failCount,
        status: appState.status,
        uptime: appState.startTime ? Math.round((Date.now() - appState.startTime) / 1000) : 0
    });
});

app.post('/api/start', async (req, res) => {
    const { atividadeId } = req.body;
    
    if (!atividadeId) return res.status(400).json({ error: 'ID obrigatório' });
    if (appState.isRunning) return res.status(409).json({ error: 'Já em execução' });
    
    appState.isRunning = true;
    appState.currentActivity = atividadeId;
    appState.status = 'starting';
    appState.startTime = Date.now();
    
    emitLog('info', `🚀 Iniciando: ${atividadeId}`);
    res.json({ success: true });
    
    // Executar automação em background
    executarAtividade(atividadeId);
});

app.post('/api/batch', async (req, res) => {
    const { atividades } = req.body;
    
    if (!atividades?.length) return res.status(400).json({ error: 'Lista vazia' });
    if (appState.isRunning) return res.status(409).json({ error: 'Já em execução' });
    
    appState.isRunning = true;
    appState.status = 'batch';
    appState.startTime = Date.now();
    
    emitLog('info', `📦 Lote iniciado: ${atividades.length} atividades`);
    io.emit('batch-start', { total: atividades.length });
    res.json({ success: true });
    
    processarLote(atividades);
});

app.post('/api/stop', (req, res) => {
    if (!appState.isRunning) return res.status(400).json({ error: 'Nada em execução' });
    
    appState.isRunning = false;
    appState.status = 'stopped';
    emitLog('warning', '🛑 Parado pelo usuário');
    res.json({ success: true });
});

app.get('/api/logs', (req, res) => {
    const limit = parseInt(req.query.limit) || 50;
    res.json(appState.logs.slice(-limit));
});

// ============================================================================
// AUTOMAÇÃO
// ============================================================================

const executarAtividade = async (atividadeId) => {
    try {
        // Iniciar navegador se necessário
        if (!appState.browser) {
            emitLog('info', '🔌 Conectando ao Chrome...');
            const { browser, page } = await iniciarAutomacao();
            appState.browser = browser;
            appState.page = page;
        }
        
        // Processar atividade
        const resultado = await processarAtividade(appState.page, atividadeId, (log) => {
            emitLog(log.type, log.message);
        });
        
        if (resultado.sucesso) {
            appState.successCount++;
            emitLog('success', `✅ ${atividadeId} concluída`);
        } else {
            appState.failCount++;
            emitLog('error', `❌ ${atividadeId} falhou: ${resultado.erro}`);
        }
        
    } catch (error) {
        appState.failCount++;
        emitLog('error', `❌ Erro: ${error.message}`);
    } finally {
        appState.totalProcessed++;
        appState.isRunning = false;
        appState.currentActivity = null;
        appState.status = appState.isRunning ? 'stopped' : 'completed';
        io.emit('status', appState);
    }
};

const processarLote = async (atividades) => {
    for (let i = 0; i < atividades.length; i++) {
        if (!appState.isRunning) break;
        
        const atividade = atividades[i];
        emitLog('info', `[${i+1}/${atividades.length}] ${atividade}`);
        io.emit('batch-progress', { current: i+1, total: atividades.length, atividade });
        
        await executarAtividade(atividade);
        
        if (i < atividades.length - 1 && appState.isRunning) {
            await new Promise(r => setTimeout(r, 2000));
        }
    }
    
    appState.isRunning = false;
    appState.status = 'completed';
    io.emit('batch-complete', { success: appState.successCount, fail: appState.failCount });
};

// ============================================================================
// WEBSOCKET
// ============================================================================

io.on('connection', (socket) => {
    console.log('🔌 Cliente conectado:', socket.id);
    socket.emit('status', appState);
    socket.emit('logs', appState.logs);
    
    socket.on('disconnect', () => {
        console.log('🔌 Cliente desconectado:', socket.id);
    });
});

// ============================================================================
// INICIAR SERVIDOR
// ============================================================================

const PORT = process.env.WEB_PORT || 3000;

httpServer.listen(PORT, () => {
    console.log('\n' + '═'.repeat(60));
    console.log('  🤖 AUTO ROBO REDECORP - SERVIDOR WEB');
    console.log('═'.repeat(60));
    console.log(`  🌐 Dashboard: http://localhost:${PORT}`);
    console.log(`  📡 API: http://localhost:${PORT}/api`);
    console.log('═'.repeat(60) + '\n');
});

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('\n🔒 Fechando navegador...');
    await fecharNavegador(appState.browser);
    process.exit(0);
});
